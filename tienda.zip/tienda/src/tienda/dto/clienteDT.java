/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tienda.dto;

/**
 *
 * @author esteban
 */
public class clienteDT {
    private int idcliente;
    private String nombre;
    private String apellidos;
    private String  rfc;
    private Long  celular; 
    private String correo;
    private String direccion;
    
    
    public int getIdcliente() {
     return idcliente;
      }
    public void setIdliente(int idcliente) {
       this.idcliente = idcliente;
        }

    public String getNombre(){
         return nombre;
    }
    public void setNombre(String nombre){
    this.nombre = nombre;
    }


    public String getApellidos(){
         return apellidos;
    }
    public void setApellidos(String apellidos){
    this.apellidos = apellidos;
    }

   public String getRfc(){
         return rfc;
    }
    public void setRfc(String rfc){
    this.rfc = rfc;
    }

    public Long getCelular() {
        return celular;
    }
    
      public void setCelular(Long celular) {
        this.celular = celular;
    }
  
    
      public String getCorreo() {
        return correo;
    }
   

      public void setCorreo(String correo) {
        this.correo = correo;
    }
      
       public String getDireccion() {
        return direccion;
    }
   
       public void setDireccion(String direccion) {
        this.direccion = direccion;
    }
    
    }



