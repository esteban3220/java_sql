/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tienda.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import tienda.dto.clienteDT;

/**
 *
 * @author esteban
 */
public class clienteDao extends coneccionBD {

private final static String SQL_INSERT="insert into cliente(nombre,apellidos,rfc,celular,correo,direccion)values(?,?,?,?,?,?)";    
private final static String SQL_UPDATE="update cliente set nombre =?, apellidos=?, rfc=?, celular=?, correo=?, direccion=? where idcliente=?";
private final static String DELETE="delete from cliente where idcliente=?";
private final static String SELECT="select * from cliente where nombre = ?";
private final static String SQL_SELECTALL="select * from cliente";

public clienteDao(){
    super();

}
public void crearCliente(clienteDT dto)throws Exception{
    PreparedStatement ps = null;
    ps = conn.prepareStatement(SQL_INSERT);
    ps.setString(1,dto.getNombre());
    ps.setString(2,dto.getApellidos());
    ps.setString(3,dto.getRfc());
    ps.setLong(4,dto.getCelular());
    ps.setString(5,dto.getCorreo());
    ps.setString(6,dto.getDireccion());
    ps.executeUpdate();
    cerrar(ps);
}

public void actualizaCliente(clienteDT dto)throws Exception{
    PreparedStatement ps = null;
    ps = conn.prepareStatement(SQL_UPDATE);
    ps.setString(1,dto.getNombre());
    ps.setString(2,dto.getApellidos());
    ps.setString(3,dto.getRfc());
    ps.setLong(4,dto.getCelular());
    ps.setString(5,dto.getCorreo());
    ps.setString(6,dto.getDireccion());
    ps.setInt(7,dto.getIdcliente());
    ps.executeUpdate();
    cerrar(ps);
}

public void eliminaCliente(clienteDT dto)throws Exception{
    PreparedStatement ps = null;
    ps = conn.prepareStatement(DELETE);
    ps.setInt(1,dto.getIdcliente());
    ps.executeUpdate();
    cerrar(ps);
}

public clienteDT busqueda(clienteDT dto)throws Exception{
    PreparedStatement ps =null;
    ResultSet rs = null;
    ps = conn.prepareStatement(SELECT);
    
    ps.setString(1, dto.getNombre());
    rs=ps.executeQuery();
    if(rs.next()){
        dto.setIdliente(rs.getInt("idcliente"));
        dto.setNombre(rs.getString("nombre"));
        dto.setApellidos(rs.getString("apellidos"));
        dto.setRfc(rs.getString("rfc"));
        dto.setCelular(rs.getLong("celular"));
        dto.setCorreo(rs.getString("Correo"));
        dto.setDireccion(rs.getString("direccion"));
    }else{
            System.err.println("No encontrado");
            return null;
         }
    return dto;
}
public List listaCliente()throws Exception{
    List lista = new ArrayList();
    PreparedStatement ps = null;
    ResultSet rs = null;
    clienteDT dto ;
    ps=conn.prepareStatement(SQL_SELECTALL);
    rs = ps.executeQuery();
    
    while(rs.next()){
        dto = new clienteDT();
        dto.setIdliente(rs.getInt("idcliente"));
        dto.setNombre(rs.getString("nombre"));
        dto.setApellidos(rs.getString("apellidos"));
        dto.setRfc(rs.getString("rfc"));
        dto.setCelular(rs.getLong("celular"));
        dto.setCorreo(rs.getString("correo"));
        dto.setDireccion(rs.getString("direccion"));
        
        lista.add(dto);
        
    }
    return lista;
}
}
 