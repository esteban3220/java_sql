/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tienda.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;



/**
 *
 * @author esteban
 */
public class coneccionBD {
protected Connection conn;

protected void cerrar(PreparedStatement stm)throws Exception{
  stm.close();   
}
protected void cerrar(ResultSet rst) throws Exception{

   rst.close();
}

    public coneccionBD() {
    String driver="org.gjt.mm.mysql.Driver";//driver mysql
    String user="Esteban";//nombre del usuario
    String pwd="junomava3842";//contraseña del usuario
    String bd="tienda";
    String server="jdbc:mysql://localhost/"+bd;
        try {
            Class.forName(driver);
           conn=DriverManager.getConnection(server,user,pwd);
        } catch (SQLException e) {
        System.out.println(e);
        
        } catch(ClassNotFoundException e){
            System.out.println(e);
    
    
    
    }
    }

}

