/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tienda.DAO;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import tienda.dto.facturaDt;

/*
 *
 *
 * @author esteban
 */
public class factura extends coneccionBD {
    
private final static String SQL_INSERT="insert into factura(idfactura,idcliente,empresa,fechapago,tipopago,precio)values(?,?,?,?,?,?)";    
private final static String SQL_UPDATE="update factura set idcliente=?, empresa=?, fechapago=?, tipopago=?, precio=? where idfactura=?";
private final static String DELETE="delete from factura where idfactura=?";
private final static String SELECT="select * from factura where empresa=?";
private final static String SQL_SELECTALL="select * from factura";


public factura(){
    super();
}

public void crearFactura(facturaDt dto)throws Exception{
    PreparedStatement ps = null;
    ps = conn.prepareStatement(SQL_INSERT);
    ps.setInt(1,dto.getIdfactura());
    ps.setInt(2,dto.getIdcliente());
    ps.setString(3,dto.getEmpresa());
    ps.setDate(4,dto.getFechaPago());
    ps.setString(5,dto.getTipoPago());
    ps.setDouble(6,dto.getPrecio());
    ps.executeUpdate();
    cerrar(ps);
}

public void actualizaFactura(facturaDt dto)throws Exception{
    PreparedStatement ps = null;
    ps = conn.prepareStatement(SQL_UPDATE);
    ps.setInt(1,dto.getIdcliente());
    ps.setString(2,dto.getEmpresa());
    ps.setDate(3,dto.getFechaPago());
    ps.setString(4,dto.getTipoPago());
    ps.setDouble(5,dto.getPrecio());
    ps.setInt(6,dto.getIdfactura());
    ps.executeUpdate();
    cerrar(ps);
}

public void eliminaFactura(facturaDt dto)throws Exception{
    PreparedStatement ps = null;
    ps = conn.prepareStatement(DELETE);
    ps.setInt(1,dto.getIdfactura());
    ps.executeUpdate();
    cerrar(ps);
}

public facturaDt busqueda(facturaDt dto)throws Exception{
    PreparedStatement ps =null;
    ResultSet rs = null;
    ps = conn.prepareStatement(SELECT);
    
    ps.setString(1, dto.getEmpresa());
    rs=ps.executeQuery();
    if(rs.next()){
        dto.setIdfactura(rs.getInt("idfactura"));
        dto.setIdcliente(rs.getInt("idcliente"));
        dto.setEmpresa(rs.getString("empresa"));
        dto.setFechaPago(rs.getDate("fechapago"));
        dto.setTipoPago(rs.getString("tipopago"));
        dto.setPrecio(rs.getDouble("precio"));
    }else{
            System.err.println("No encontrado");
            return null;
         }
    return dto;
}
public List listaFactura()throws Exception{
    List lista = new ArrayList();
    PreparedStatement ps = null;
    ResultSet rs = null;
    facturaDt dto ;
    ps=conn.prepareStatement(SQL_SELECTALL);
    rs = ps.executeQuery();
    
    while(rs.next()){
        dto = new facturaDt();
        dto.setIdfactura(rs.getInt("idfactura"));
        dto.setIdcliente(rs.getInt("idcliente"));
        dto.setEmpresa(rs.getString("empresa"));
        dto.setFechaPago(rs.getDate("fechapago"));
        dto.setTipoPago(rs.getString("tipopago"));
        dto.setPrecio(rs.getDouble("precio"));
        lista.add(dto);
    }
    return lista;
}
}

