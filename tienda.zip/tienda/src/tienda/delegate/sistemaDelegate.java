/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tienda.delegate;

import tienda.DAO.clienteDao;
import tienda.dto.clienteDT;
import java.util.List;
import tienda.DAO.factura;
import tienda.dto.facturaDt;

/**
 *
 * @author esteban
 */
public class sistemaDelegate {
    public void agregarCliente(clienteDT dto)throws Exception{
        clienteDao dao = new clienteDao();
        dao.crearCliente(dto);
    }

    public void modificaCliente(clienteDT dto)throws Exception{
        clienteDao dao = new clienteDao();
        dao.actualizaCliente(dto);    
    }
    
    public void borrarCliente(clienteDT dto)throws Exception{
        clienteDao dao = new clienteDao();
        dao.eliminaCliente(dto);
    }
    public clienteDT buscarCliente(clienteDT dto)throws Exception{
    clienteDao dao = new clienteDao();
    return dao.busqueda(dto);
    }
    
    public List lsCliente()throws Exception{
    clienteDao dao = new clienteDao();
    return dao.listaCliente();
    }
    
    
    //ancapsulamiento factura
    
    public void agregarFactura (facturaDt dto) throws Exception{
        factura dao = new factura();
        dao.crearFactura(dto);
    }
    
    public void modificaFactura (facturaDt dto) throws Exception{
        factura dao = new factura();
        dao.actualizaFactura(dto);
    }
    
    public void borrarFactura (facturaDt dto) throws Exception{
        factura dao = new factura();
        dao.eliminaFactura(dto);
    }
    
    public facturaDt buscarFactura (facturaDt dto) throws Exception{
        factura dao = new factura();
        return dao.busqueda(dto);
    }
    
    public List lsFactura (facturaDt dto) throws Exception{
        factura dao = new factura();
        return dao.listaFactura();
    }
    public  Object[] numeros(int inicio,int fin){
        Object[] num = new Object[(fin-inicio+1)];
        
        int y =0;
        for(int x=inicio;x<=fin;x++){
            num[y]= x;
            y++;
        }
        return num;
    }
}
